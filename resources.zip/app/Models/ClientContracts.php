<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientContracts extends Model
{
    //
}