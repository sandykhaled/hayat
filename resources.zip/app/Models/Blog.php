<?php

namespace App\Models;

use App\Models\Image;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Blog extends Model
{
    use HasFactory;



    protected $fillable = ['title_ar',  'title_en', 'description_ar' , 'description_en' ,'image'];
    public function getFileLink()
{
    return $this->image != null ? asset('uploads/blogs/' . $this->image) : '';
}

}
