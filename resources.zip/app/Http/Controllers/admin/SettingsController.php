<?php

namespace App\Http\Controllers\admin;

use Response;
use App\Models\Settings;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SettingsController extends Controller
{
    public function generalSettings()
    {
        if (!userCan('settings_view')) {
            return redirect()->back()
                ->with('PopError', trans('common.youAreNotAuthorized'));
        }
        $settings = Settings::get()->keyBy('key')->all();
        return view('AdminPanel.settings.index',
            [
                'title' => trans('common.setting'),
                'active' => 'setting',
                'settings' => $settings,
                'breadcrumbs' => [
                    [
                        'url' => '',
                        'text' => trans('common.setting')
                    ]
                ]
            ]);
    }

    public function updateSettings(Request $request)
    {
        $this->validate($request, [
            'sessionPrice2' => 'required|numeric',
        ]);

        //foreach inputs which is text ant textarea
        foreach ($_POST as $key => $value) {
            if ($key != '_token') {
                $setting = Settings::where('key', $key)->first();
                if ($setting == '') {
                    $setting = New Settings;
                    $setting->key = $key;
                    $setting->save();
                }
                $setting->value = $value;
                $setting->update();
            }
        }


        session()->flash('success', trans('common.successMessageText'));
        return back();

    }

}
