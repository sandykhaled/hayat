<li class="nav-item d-none d-lg-block">
    <a class="nav-link nav-link-style" onclick="changeAdminStyle()">
        <i class="ficon" data-feather="{{themeModeClasses()['icon']}}"></i>
    </a>
</li>