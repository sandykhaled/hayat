<?php
return [
    'pleaseSendLangCode' => 'من فضلك ارسل بيانات اللغة',
    'someThingWentWrong' => 'يوجد خطأ ما في الاستعلام في قاعدة البيانات تواصل مع الدعم الفني',
    'yourDataHasBeenSavedSuccessfully' => 'تم حفظ البيانات بنجاح',
    'pleaseRecheckYourDetails' => 'من فضلك راجع بياناتك مرة أخرى يوجد لديك خطأ في البيانات',
    'youCantLogIn' => 'لا يمكنك تسجيل الدخول بهذه الطريقة حيث أن بياناتك ليست بيانات عميل',
    'yourDataIsWrong' => 'البيانات التي قمت بإدخالها غير صحيحه قم بالمحاولة مرة أخرى',
    'youHaveBeenBlockedFromLoggingToOurSystem' => 'لقد قمنا بحظر حسابك من استخدام المنصة الخاصة بنا يمكنك التواصل معنا من خلال صفحة اتصل بنا لمعلومات أكثر',
    'yourAccountIsNotActive' => 'عفواً حسابك لم يتم تفعيله بعد يجب أن تقوم بتفعيل حسابك عبر رسالة التفعيل التي وصلت إلى بريدك الإلكتروني',
    'thisUserDoesNotExist' => 'عفواً لا يوجد أي بيانات لهذا الحساب',
    'yourDataHasBeenSentSuccessfully' => 'تم إرسال البيانات بنجاح',
    'yourOrderHasBeenSentSuccessfully' => 'تم إرسال بيانات الطلب الخاص بك بنجاح'
];